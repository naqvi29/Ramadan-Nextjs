"use strict";
(() => {
var exports = {};
exports.id = 859;
exports.ids = [859];
exports.modules = {

/***/ 199:
/***/ ((module) => {

module.exports = require("adhan");

/***/ }),

/***/ 167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 535:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: ./utils/prayerTimes.js
const { PrayerTimes , CalculationMethod , Coordinates , Madhab  } = __webpack_require__(199);
const axios = __webpack_require__(167);
const moment = __webpack_require__(245);
// export function getPrayerTimes(latitude, longitude) {
//   // Define the location coordinates dynamically
//   const coordinates = new Coordinates(latitude, longitude);
//   // Set calculation parameters
//   const params = CalculationMethod.MuslimWorldLeague();
//   params.madhab = Madhab.Hanafi;
//   // Use a JavaScript Date object for the current date
//   const today = new Date();
//   // Calculate prayer times
//   const prayerTimes = new PrayerTimes(coordinates, today, params);
//   // Format time for output
//   const formatTime = (date) => {
//     return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
//   };
//   return {
//     sehriTime: formatTime(prayerTimes.fajr),
//     iftariTime: formatTime(prayerTimes.maghrib)
//   };
// }
function adjustTime(timeStr, adjustment) {
    // Parse the time string
    const [time, meridian] = timeStr.split(" ");
    const [hours, minutes] = time.split(":").map(Number);
    // Create a Date object
    const date = new Date();
    date.setHours(meridian.toLowerCase() === "pm" && hours !== 12 ? hours + 12 : hours % 12);
    date.setMinutes(minutes + adjustment);
    // Adjust for overflow or underflow of minutes
    date.setSeconds(0);
    // Format the updated time
    const updatedHours = date.getHours();
    const updatedMinutes = date.getMinutes();
    const updatedMeridian = updatedHours >= 12 ? "pm" : "am";
    const formattedHours = (updatedHours + 11) % 12 + 1; // Convert to 12-hour format
    const formattedMinutes = updatedMinutes.toString().padStart(2, "0");
    return `${formattedHours}:${formattedMinutes} ${updatedMeridian}`;
}
async function getPrayerTimes2(city) {
    try {
        // API endpoint
        const url = `https://muslimsalat.com/${city}/daily.json`;
        // Make API request
        const response = await axios.get(url, {
        });
        // Parse response data
        const data = response.data;
        if (data.status_code !== 1) {
            throw new Error(`Failed to fetch prayer times: ${data.status_description}`);
        }
        // Extract Sehar (Fajr) and Iftar (Maghrib) times
        const items = data.items[0];
        const dateFor = items.date_for;
        const formattedDate = moment(dateFor).format("Do MMMM YYYY");
        const sehriTime = items.fajr;
        const iftariTime = items.maghrib;
        // Decrement 1 minute for Sehri time
        const updatedSehriTime = adjustTime(sehriTime, -2);
        // Increment 1 minute for Iftar time
        const updatedIftariTime = adjustTime(iftariTime, 1);
        const iftariTimeJafria = adjustTime(updatedIftariTime, 10);
        const sehriTimejafria = adjustTime(updatedSehriTime, -10);
        // Return formatted times
        return {
            updatedSehriTime,
            updatedIftariTime,
            sehriTimejafria,
            iftariTimeJafria,
            formattedDate
        };
    // return {
    //       sehriTime: sehriTime,
    //       iftariTime: iftariTime
    // };
    } catch (error) {
        console.error("Error fetching prayer times:", error.message);
        throw error;
    }
}

;// CONCATENATED MODULE: ./pages/api/prayerTimes.js
// pages/api/prayerTimes.js

async function handler(req, res) {
    if (req.method === "POST") {
        try {
            const { city  } = req.body;
            console.log("CITYYY");
            console.log(city);
            if (!city) {
                return res.status(400).json({
                    error: "City is required"
                });
            }
            const times = await getPrayerTimes2(city);
            res.status(200).json(times);
        } catch (error) {
            console.error("Error fetching prayer times:", error);
            res.status(500).json({
                error: "Failed to fetch prayer times"
            });
        }
    } else {
        res.status(405).json({
            error: "Method not allowed"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(535));
module.exports = __webpack_exports__;

})();