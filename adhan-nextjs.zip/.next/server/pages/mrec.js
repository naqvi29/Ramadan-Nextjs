"use strict";
(() => {
var exports = {};
exports.id = 37;
exports.ids = [37];
exports.modules = {

/***/ 6:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./utils/prayerTimes.js
const { PrayerTimes , CalculationMethod , Coordinates , Madhab  } = __webpack_require__(199);
const axios = __webpack_require__(167);
const moment = __webpack_require__(245);
// export function getPrayerTimes(latitude, longitude) {
//   // Define the location coordinates dynamically
//   const coordinates = new Coordinates(latitude, longitude);
//   // Set calculation parameters
//   const params = CalculationMethod.MuslimWorldLeague();
//   params.madhab = Madhab.Hanafi;
//   // Use a JavaScript Date object for the current date
//   const today = new Date();
//   // Calculate prayer times
//   const prayerTimes = new PrayerTimes(coordinates, today, params);
//   // Format time for output
//   const formatTime = (date) => {
//     return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
//   };
//   return {
//     sehriTime: formatTime(prayerTimes.fajr),
//     iftariTime: formatTime(prayerTimes.maghrib)
//   };
// }
function adjustTime(timeStr, adjustment) {
    // Parse the time string
    const [time, meridian] = timeStr.split(" ");
    const [hours, minutes] = time.split(":").map(Number);
    // Create a Date object
    const date = new Date();
    date.setHours(meridian.toLowerCase() === "pm" && hours !== 12 ? hours + 12 : hours % 12);
    date.setMinutes(minutes + adjustment);
    // Adjust for overflow or underflow of minutes
    date.setSeconds(0);
    // Format the updated time
    const updatedHours = date.getHours();
    const updatedMinutes = date.getMinutes();
    const updatedMeridian = updatedHours >= 12 ? "pm" : "am";
    const formattedHours = (updatedHours + 11) % 12 + 1; // Convert to 12-hour format
    const formattedMinutes = updatedMinutes.toString().padStart(2, "0");
    return `${formattedHours}:${formattedMinutes} ${updatedMeridian}`;
}
async function getPrayerTimes2(city) {
    try {
        // API endpoint
        const url = `https://muslimsalat.com/${city}/daily.json`;
        // Make API request
        const response = await axios.get(url, {
        });
        // Parse response data
        const data = response.data;
        if (data.status_code !== 1) {
            throw new Error(`Failed to fetch prayer times: ${data.status_description}`);
        }
        // Extract Sehar (Fajr) and Iftar (Maghrib) times
        const items = data.items[0];
        const dateFor = items.date_for;
        const formattedDate = moment(dateFor).format("Do MMMM YYYY");
        const sehriTime = items.fajr;
        const iftariTime = items.maghrib;
        // Decrement 1 minute for Sehri time
        const updatedSehriTime = adjustTime(sehriTime, -2);
        // Increment 1 minute for Iftar time
        const updatedIftariTime = adjustTime(iftariTime, 1);
        const iftariTimeJafria = adjustTime(updatedIftariTime, 10);
        const sehriTimejafria = adjustTime(updatedSehriTime, -10);
        // Return formatted times
        return {
            updatedSehriTime,
            updatedIftariTime,
            sehriTimejafria,
            iftariTimeJafria,
            formattedDate
        };
    // return {
    //       sehriTime: sehriTime,
    //       iftariTime: iftariTime
    // };
    } catch (error) {
        console.error("Error fetching prayer times:", error.message);
        throw error;
    }
}

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./components/Ramzan.js


 // Import the CSS module
function Ramzan({ sehriTime , iftariTime , sehriTimeJafria , iftariTimeJafria , city , date  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bgRamadan d-flex flex-column align-items-center justify-content-between text-white",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: "/logo.png",
                    className: "img-fluid color-invert w-50",
                    alt: "Logo"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "text-center mt-2 font-shadow",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        className: "mb-1",
                        children: city
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "mb-0 small",
                        children: date
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "d-flex flex-column align-items-center mt-3 w-100 sm-font",
                children: /*#__PURE__*/ jsx_runtime_.jsx("table", {
                    className: "table w-75 text-center",
                    style: {
                        borderSpacing: "4px",
                        borderCollapse: "separate"
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "text-left md-font align-middle border-0 head-color",
                                        rowSpan: "2",
                                        children: "Iftari"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg font-heading",
                                        children: "HANAFI"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: "span-bg time",
                                        children: [
                                            iftariTime,
                                            " "
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg font-heading",
                                        children: "JAFRI"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg time",
                                        children: iftariTimeJafria
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("tr", {
                                className: "spacing-row"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        rowSpan: "2",
                                        className: "text-left md-font align-middle border-0 head-color",
                                        children: "Sehri"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg font-heading",
                                        children: "HANAFI"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg time",
                                        children: sehriTime
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg font-heading",
                                        children: "JAFRI"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "span-bg time",
                                        children: sehriTimeJafria
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "p-note",
                children: "Disclaimer: Sehri and Iftar times may vary slightly (\xb11 min)."
            })
        ]
    });
}

;// CONCATENATED MODULE: ./pages/mrec/index.js



// import '../../styles/global.css'
// import styles from '../../styles/zam.css';


async function getServerSideProps() {
    try {
        // Fetch geolocation data
        const response = await fetch("https://get.geojs.io/v1/ip/geo.json");
        const geoData = await response.json();
        // Extract latitude, longitude, timezone, and country with fallback values
        const timezone = geoData.timezone;
        const city = timezone.split("/")[1];
        // Get prayer times based on user's location if latitude and longitude are valid
        let sehriTime = "N/A";
        let iftariTime = "N/A";
        let sehriTimeJafria = "N/A";
        let iftariTimeJafria = "N/A";
        let date = "N/A";
        if (city) {
            const times = await getPrayerTimes2(city);
            sehriTime = times.updatedSehriTime;
            iftariTime = times.updatedIftariTime;
            sehriTimeJafria = times.sehriTimejafria;
            iftariTimeJafria = times.iftariTimeJafria;
            date = times.formattedDate;
        }
        return {
            props: {
                sehriTime,
                iftariTime,
                sehriTimeJafria,
                iftariTimeJafria,
                timezone,
                city,
                date
            }
        };
    } catch (error) {
        console.error("Error fetching geolocation data:", error);
        // Provide fallback data if API fails
        return {
            props: {
                sehriTime: "N/A",
                iftariTime: "N/A",
                sehriTimeJafria: "N/A",
                iftariTimeJafria: "N/A",
                timezone: "Unknown",
                city: "Unknown",
                date: "N/A"
            }
        };
    }
}
function Home({ sehriTime , iftariTime , sehriTimeJafria , iftariTimeJafria , timezone , city , date  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Ramzan, {
            sehriTime: sehriTime,
            iftariTime: iftariTime,
            sehriTimeJafria: sehriTimeJafria,
            iftariTimeJafria: iftariTimeJafria,
            timezone: timezone,
            city: city,
            date: date
        })
    });
}


/***/ }),

/***/ 199:
/***/ ((module) => {

module.exports = require("adhan");

/***/ }),

/***/ 167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6));
module.exports = __webpack_exports__;

})();